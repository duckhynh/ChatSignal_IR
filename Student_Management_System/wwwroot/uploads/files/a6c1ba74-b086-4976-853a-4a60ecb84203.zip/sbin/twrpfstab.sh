#!/sbin/sh
# Init TWRP recovery TWRP shell script SlimHouse 2021-10-21
# This script will add additional partitions into /etc/twrp.fstab 
echo $(date +%F' '%H:%M:%S) - Script add partitions into /etc/twrp.fstab script started.... > /tmp/inittwrp.log
if [ -f /etc/twrp.fstab ]
then 
 /sbin/cp /etc/twrp.fstab /etc/twrp.fstab.orig
fi
echo '# Add partition founded on device by script...' >> /etc/twrp.fstab
ls -a /dev/block | grep tee      && echo '/tee            ext4    /dev/block/tee         flags=backup=1;display=Tee' >> /etc/twrp.fstab
ls -a /dev/block | grep tee      && echo '/tee_image      emmc    /dev/block/tee         flags=backup=1;flashimg;display="Tee Image"' >> /etc/twrp.fstab
ls -a /dev/block | grep vendor   && echo '/vendor         ext4    /dev/block/vendor      flags=backup=1;display=Vendor' >> /etc/twrp.fstab
ls -a /dev/block | grep vendor   && echo '/vendor_image   emmc    /dev/block/vendor      flags=backup=1;flashimg;display="Vendor Image"' >> /etc/twrp.fstab
ls -a /dev/block | grep odm      && echo '/odm            ext4    /dev/block/odm         flags=backup=1;display=Odm' >> /etc/twrp.fstab
ls -a /dev/block | grep odm      && echo '/odm_image      emmc    /dev/block/odm         flags=backup=1;flashimg;display="Odm Image"' >> /etc/twrp.fstab
ls -a /dev/block | grep param    && echo '/param          ext4    /dev/block/param       flags=backup=1;display=Param' >> /etc/twrp.fstab
ls -a /dev/block | grep param    && echo '/param_image    emmc    /dev/block/param       flags=backup=1;flashimg;display="Param Image"' >> /etc/twrp.fstab
ls -a /dev/block | grep product  && echo '/product        ext4    /dev/block/product     flags=backup=1;display=Product' >> /etc/twrp.fstab
ls -a /dev/block | grep product  && echo '/product_image  emmc    /dev/block/product     flags=backup=1;flashimg;display="Product Image"' >> /etc/twrp.fstab
ls -a /dev/block | grep metadata && echo '/metadata       ext4    /dev/block/metadata    flags=backup=1;display=Metadata' >> /etc/twrp.fstab
ls -a /dev/block | grep metadata && echo '/metadata_image emmc    /dev/block/metadata    flags=backup=1;flashimg;display="Metadata Image"' >> /etc/twrp.fstab
awk 'NR>1 { print $4 }'  /proc/inand |  tr -d \" | sort | grep -Ev "system|data|cache|boot|recovery|logo|bootloader|tee|vendor|odm|param|product|metadata" | while read line; do echo -e '/'$line"\t"'emmc'"\t"'/dev/block/'$line"\t"'flags=backup=1;display='$line'.img'>> /etc/twrp.fstab; done
ls -a /dev/block | grep mmcblk0boot0 && echo '/blk0boot0         emmc    /dev/block/mmcblk0boot0      flags=backup=1;display=mmcblk0boot0.img' >> /etc/twrp.fstab
ls -a /dev/block | grep mmcblk0boot1 && echo '/blk0boot1         emmc    /dev/block/mmcblk0boot1      flags=backup=1;display=mmcblk0boot1.img' >> /etc/twrp.fstab
echo '# Additional partition from script - end line' >> /etc/twrp.fstab
echo $(date +%F' '%H:%M:%S) - Script add partitions into /etc/twrp.fstab script ended.... > /tmp/inittwrp.log
exit 0

