#!/sbin/sh
# Reboot to system TWRP shell script SlimHouse 2021-10-21
# This script check rebootsystem.sh file from int/ext sdcard or ext USB drive from root TWRP folder
# If rebootsystem.sh will found on user space device 
# then this script will be executed from /tmp folder TWRP recovery
echo $(date +%F' '%H:%M:%S) - TWRP script /sbin/rebootsystem.sh started.... > /tmp/rebootsystem.log
if [ -f /sdcard/TWRP/rebootsystem.sh ]
    then file_exec=/sdcard/TWRP/rebootsystem.sh
elif [ -f /external_sd/TWRP/rebootsystem.sh ]
    then file_exec=/external_sd/TWRP/rebootsystem.sh
elif [ -f /udisk/TWRP/rebootsystem.sh ]
    then file_exec=/udisk/TWRP/rebootsystem.sh
elif [ -f /usb-otg/TWRP/rebootsystem.sh ]
    then file_exec=/usb-otg/TWRP/rebootsystem.sh
else    
    echo - User script rebootsystem.sh not found on user space devices >> /tmp/rebootsystem.log
    exit 0
fi
echo $(date +%F' '%H:%M:%S) - User script $file_exec found on user space devices >> /tmp/rebootsystem.log
cp $file_exec /tmp/rebootsystem.sh
chmod 755 /tmp/rebootsystem.sh
/tmp/rebootsystem.sh
echo $(date +%F' '%H:%M:%S) - User script $file_exec executed from /tmp/ folder >> /tmp/rebootsystem.log
